#' Transform a function that reports error when input is negative into a function that return a list which records the erro condition
#'
#' @param f a function that reports error when input is negative
#'
#' @return another function that 1. if input is greater than 0, then return normal output; 2. if input is invalid, return an error condition object, with "invalid_input" subclass and invalid value attached.
#' @export
#'
#' @examples
#' f_operator(my_sqrt_1)
f_operator = function(f){

  force(f)
  #your code here (hint1: use catch_cnd() in pkg rlang)
  erro_func = function(x){
    if(x<0){
      catch_cnd(rlang::abort(message = "negative input, NA introduced!",
                             .subclass ="invalid_input",
                             invalid_input = x))
    } else{
      return(f(x))
    }

  }

}
