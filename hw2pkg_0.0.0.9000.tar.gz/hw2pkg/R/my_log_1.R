#' A variation of log that reports error when the input is negative
#'
#' @param x a real number
#'
#' @return error when x is negative and the square root of x when x is non-negative
#' @export
#'
#' @examples
#' my_log_1(-1)
#' my_log_1(4)
my_log_1 = function(x){
  #your code here
  if(x<0){
    rlang::abort(message = "negative input, NA introduced!",
                 .subclass ="get_val_error",
                 val = x)
  } else{
    log(x)
  }
}
